CREATE TABLE `records` (
	`id` text PRIMARY KEY NOT NULL,
	`kind` text NOT NULL,
	`data` text NOT NULL,
	`updated` text NOT NULL
);

CREATE TABLE `sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`last` integer NOT NULL
);

CREATE TABLE `users` (
	`id` text PRIMARY KEY NOT NULL,
	`username` text NOT NULL,
	`name` text NOT NULL,
	`hash` text NOT NULL,
	`salt` text NOT NULL,
	`role` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL
);

CREATE UNIQUE INDEX `users_username_unique` ON `users` (`username`);
ALTER TABLE `records` ADD `workspace` text DEFAULT 'legacy' NOT NULL;
ALTER TABLE `users` ADD `workspace` text DEFAULT 'legacy' NOT NULL;